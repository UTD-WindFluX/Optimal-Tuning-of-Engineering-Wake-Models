function c=nancorr(x,y)
    x=reshape(x,[],1);
    y=reshape(y,[],1);
    
    reals=~isnan(x+y);
    
    x=x(reals);
    y=y(reals);
    
    c=corr(x,y);
end