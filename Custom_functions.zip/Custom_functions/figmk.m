function [fig] = figmk(c,d)
fig = figure('Color','w','Units','normalized','Position', [0.3, 0.3, c,d]);
