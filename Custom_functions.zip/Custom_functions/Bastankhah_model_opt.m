function [Bast]= Bastankhah_model_opt(U_field, Xm, Rm, Ct_vec,k_vec,eps_vec)
% Given the Lidar data, optimize the parameter in Bastankhah model.
%% Input
X_start = 1.75;
X_down = 7;
R = Rm(:,1);
X = Xm(1,:);
Nc = length(Ct_vec);
Nk = length(k_vec);
Ne = length(eps_vec);

PE_Bast = nan(Nc,Nk,Ne);
Thres_corr = 0.99; % Fernando et.al2018


Vec1 = reshape(U_field,[],1);
x_index = match(X,X_start):match(X,X_down); % Range of data to be considered


%% Main


for id_ct = 1:Nc
    for id_k = 1:Nk
        for id_eps = 1:Ne
            
            disp(['Bastankhah: ',num2str(((id_ct-1)*Nk*Ne+(id_k-1)*Ne+id_eps)/(Nc*Nk*Ne)*100),'%'])
           
            %Gaussian fitting and 
            U_gau = nan(length(R),length(x_index));
            coeff = nan(length(x_index),4);
            rho_nwl = nan(1,length(x_index));
            for x_id = 1:length(x_index)
                [fitting,~,~]=Gauss_4P(R,U_field(:,x_index(x_id)));
                if ~isempty(fitting)
                    U_gau(:,x_id)=feval(fitting,R);
                    coeff(x_id,:)=coeffvalues(fitting);  
                    rho_nwl(x_id) =  nancorr(U_field(:,x_index(x_id)), U_gau(:,x_id));%NWL
                else
                    coeff(x_id,:)=NaN;
                    rho_nwl(x_id) =  nan;
                end
            end
                
            % Near wake length
            if ~isempty(find(rho_nwl>=Thres_corr,1,'first'))
                index_nwl = find(round(rho_nwl,2)>=Thres_corr,1,'first');
                NWL = X(x_index(index_nwl));
            else
                NWL = nan;
            end
            
            % Compute the PE
            epsilon = eps_vec(id_eps);
            Ct_test=Ct_vec(id_ct);
            k_test=k_vec(id_k);
            Xmin = ceil(max((sqrt(Ct_test/8)-epsilon)*1/(k_test),0));
            
            if ~isnan(NWL)
                X_ini = NWL;
            else
                X_ini = 1;
            end
            if Xmin<=(X_ini)% the minimum distance to consider for the real solution 
                Induction = (1 - sqrt(1 - Ct_test./(8*(k_test*Xm+epsilon).^2)));
                Induction(imag(Induction)~=0)=NaN;

                BP_Um = 1 - Induction.*exp(-1./(2*(k_test*Xm+epsilon).^2).*Rm.^2);
                Vec2 = reshape(BP_Um,[],1);
                index_x_r = reshape(logical((abs(Xm)<=X_down).*(abs(Xm)>=X_ini)),[],1);
        %         Norm_vec(id_ct,id_k) = norm(Vec1(index_r) - Vec2(index_r));
                PE_Bast(id_ct,id_k,id_eps) = nanmean(abs(Vec2(index_x_r) - Vec1(index_x_r))./Vec1(index_x_r)); 
            else
                PE_Bast(id_ct,id_k,id_eps) = nan;
            end
        end
    end
end 

% The minimum PE
min_index = find(PE_Bast==(nanmin(nanmin(nanmin(PE_Bast)))));
[index_ctmin,index_kmin,index_epsmin] = ind2sub(size(PE_Bast),min_index);
Pen_Bast_min = PE_Bast(index_ctmin,index_kmin,index_epsmin);

Ct_opt = Ct_vec(index_ctmin);
k_opt = k_vec(index_kmin);
eps_opt = eps_vec(index_epsmin);
Induction = (1 - sqrt(1 - Ct_opt./(8*(k_opt*Xm+eps_opt).^2)));
Induction(imag(Induction)~=0)=NaN;% reject the complex solution
% R_bas_opt = eps_opt + 2*k_opt*(Xm);
BP_Umopt = 1 - Induction.*exp(-1./(2*(k_opt*Xm+eps_opt).^2).*Rm.^2);

%% Export data
Bast.PE_min =  Pen_Bast_min;
Bast.BP_Umopt = BP_Umopt;
Bast.NWL = NWL;
Bast.Ct_opt = Ct_opt;
Bast.k_opt = k_opt;
Bast.eps_opt = eps_opt;

