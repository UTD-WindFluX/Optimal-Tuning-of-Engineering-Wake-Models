function [u_lidar,v_lidar,b_lidar,epsilon_lidar,GRAS,Mass_chk] = Ainslie_wake_UV_u0_v3(X_ans,R_ans,X_lidar,Y_lidar,u0,km,kl,w_edge)
% 10/19/2019 w_edge added as input
% 10/28/2019 v advanced direction modified

% Test purpose
% X_lidar=Xm_half;
% Y_lidar=Rm_half;
% km=km_opt;
% kl=kl_opt;
%% Ainslie wake model with U and V both solved

%Grid for Ainslie
Mx=size(X_ans,2);
Mr=size(X_ans,1);
X=X_ans(1,:);
R=R_ans(:,1);

%Differetiation matrices
dr=R(1)-R(2);dx=X(2)-X(1);
Dr=zeros(Mr);D2r=zeros(Mr);
Dr(1,1)=1/dr;
Dr(1,2)=-1/dr;
Dr(Mr,Mr)=-1/dr;
Dr(Mr,Mr-1)=1/dr;

D2r(1,1)=0.5/dr^2;
D2r(1,2)=-1/dr^2;
D2r(1,3)=0.5/dr^2;

D2r(Mr,Mr)=0.5/dr^2;
D2r(Mr,Mr-1)=-1/dr^2;
D2r(Mr,Mr-2)=0.5/dr^2;

for i=2:Mr-1
    Dr(i,i-1)=1/(2*dr);
    Dr(i,i+1)=-1/(2*dr);

    D2r(i,i-1)=1/dr^2;
    D2r(i,i)=-2/dr^2;
    D2r(i,i+1)=1/dr^2;
end


%% Initialize
u=zeros(Mr,Mx);
v=zeros(Mr,Mx);
u(:,1)=u0;
% w_edge = 0.9;
% v(:,1)=u0;

% v(end,:)=0.5;

epsilon=zeros(Mr,Mx);
% somehow in ref: Improving Jensen and Larsen wake deficit model has using this formula
% figure;hold on;
% plot(X,real(F) - imag(F)) ;

dvdr = zeros(Mr,Mx);

for id_x = 1:Mx-1
    
    dudr(:,id_x)=(Dr*u(:,id_x));dudr([1 end],id_x)=0;% Central difference.
    d2udr2(:,id_x)=D2r*u(:,id_x);
    invR=1./(R);
    
%     [~,bb]=min(abs(u(:,id_x)-(1-2.83/100)));% wake width is defined as the 2.83% percentage of the of tis centerline wihte.
    bb = match(u(:,id_x),w_edge);% 9*% as the wake width
    if ~isempty(bb)
        b(id_x)= R(bb);% min(R(bb),prctile(u(:,id_x),0.9717));%R(bb);
    else
        b(id_x)= nan;
    end
    F_filter(id_x)= 1;

    epsilon(:,id_x)=F_filter(id_x)*(kl*b(id_x)*(1-u(Mr,id_x))+km); % km is found in the lookup table.
    RHS(:,id_x) = epsilon(:,id_x).*(invR.*dudr(:,id_x) + d2udr2(:,id_x));
    for id_r = Mr-1:-1:1
    % v starts from the rotor, assume v(Nr,x) = 0 there,
        dvdr(id_r,id_x) = (v(id_r+1,id_x)*(dudr(id_r,id_x) - u(id_r,id_x)/R(id_r)) - RHS(id_r,id_x))/u(id_r,id_x);
        v(id_r,id_x) = dvdr(id_r,id_x)*dr + v(id_r+1,id_x);
    end
    dvdr(1,id_x) = dvdr(2,id_x);
    dudx(:,id_x) = (RHS(:,id_x) - v(:,id_x).*dudr(:,id_x))./u(:,id_x);
    
    u(:,id_x+1)= dudx(:,id_x)*dx + u(:,id_x);
    u(1,id_x+1)=u(2,id_x+1);
    u(Mr,id_x+1)=u(Mr-1,id_x+1)-dudr(Mr-1,id_x)*dr;
end
b(Mx) = b(Mx-1);
dudr(:,Mx) = dudr(:,Mx-1);
d2udr2(:,Mx) = d2udr2(:,Mx-1);
dudx(:,Mx) = dudx(:,Mx-1);
RHS(:,Mx) = RHS(:,Mx-1);
% dvdr = -flipud(dvdr);
%% output data
GRAS.dudx = interp2(X_ans,R_ans,dudx,X_lidar,Y_lidar);
GRAS.dudr = interp2(X_ans,R_ans,dudr,X_lidar,Y_lidar);
GRAS.dvdr = interp2(X_ans,R_ans,dvdr,X_lidar,Y_lidar);
GRAS.d2udr2 = interp2(X_ans,R_ans,d2udr2,X_lidar,Y_lidar);
GRAS.Dr = Dr;
GRAS.D2r = D2r;

u_lidar = interp2(X_ans,R_ans,u,X_lidar,Y_lidar);
v_lidar = interp2(X_ans,R_ans,v,X_lidar,Y_lidar);
b_lidar = interp1(X_ans(1,:),b,X_lidar(1,:));
epsilon_lidar = interp2(X_ans,R_ans,epsilon,X_lidar,Y_lidar);

Mass_chk = GRAS.dudx+GRAS.dvdr+v_lidar./Y_lidar;
end