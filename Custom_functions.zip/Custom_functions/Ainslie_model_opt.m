function [Ains]= Ainslie_model_opt(U_field, Xm, Rm, km_vec,kl_vec)

w_edge = 0.9;
X_start = 1.75;
X_down = 7;

R = Rm(:,1);
X = Xm(1,:);
Nr_og = length(R);
Nx_og = length(X);
Xm_half = Xm(R>0,:);
Rm_half = Rm(R>0,:);

x_index = match(X,X_start):match(X,X_down); % Range of data to be considered

% Gird 
Nx=15000; 
Nr=100;
R_max = 1.5;
[X_ans,R_ans]=meshgrid(linspace(0,10,Nx),linspace(R_max,0,Nr));

Vec1 = reshape(U_field,[],1);

%% Main
tic
% The first profile that is not zero
index_x0 = find(~isnan(U_field((Nr_og/2),x_index)),1,'first');
X_initial = X(x_index(index_x0));
% symmetric wake profile as input for Ainslie
u0_sym=mean([flipud(U_field(1:(Nr_og/2),index_x0)),U_field((Nr_og/2+1):Nr_og,index_x0)],2);
u0 = inpaint_nans(interp1(Rm((Nr_og/2+1):Nr_og,1),u0_sym,R_ans(:,1)));
% new method
for id_km = 1:length(km_vec)
    for id_kl = 1:length(kl_vec)
        disp(['Ainslie: ',  num2str( ((id_km-1)*length(kl_vec) + id_kl)/(length(km_vec)*length(kl_vec))*100),'%'])
        km_test = km_vec(id_km);
        kl_test = kl_vec(id_kl);

        % Ainslie
        [AS_Um_half,~,b,~,~] = Ainslie_wake_UV_u0_v3(X_ans+X_initial,R_ans,Xm_half,Rm_half,u0,km_test,kl_test,w_edge);
        AS_Um = [flipud(AS_Um_half);AS_Um_half];
        Index_x_r= reshape(logical((abs(Xm)<=X_down).*(abs(Rm)>0)),[],1);

        Vec2 = reshape(AS_Um,[],1);

        % Calculate Norm
        PE_ains(id_km,id_kl) = nanmean(abs(Vec2(Index_x_r) - Vec1(Index_x_r))./Vec1(Index_x_r)); 
    end
end

PE_ains(PE_ains==0)=nan;
min_index = find(PE_ains==(nanmin(nanmin(PE_ains))));
[index_kmmin,index_klmin] = ind2sub(size(PE_ains),min_index);
PE_ans_min = PE_ains(index_kmmin,index_klmin);

km_opt = km_vec(index_kmmin);
kl_opt = kl_vec(index_klmin);
[AS_opt_half,~,Rw_opt,~,~] = Ainslie_wake_UV_u0_v3(X_ans+X_initial,R_ans,Xm_half,Rm_half,u0,km_opt,kl_opt,w_edge);

AS_opt = [flipud(AS_opt_half);AS_opt_half];
%             AS_opt(abs(Rm)>repmat(Rw_opt,size(Rm,1),1)) = 1;

%% Export data

Ains.PE_min_reslt =  PE_ans_min;
Ains.X_ans =X_ans;
Ains.R_ans =R_ans;
Ains.AS_opt = AS_opt;
Ains.Rw_opt = Rw_opt;
Ains.X_initial = X_initial;


Ains.km_opt = km_opt;
Ains.kl_opt = kl_opt;
           