function [Index,Diff_val] = match(a,b,max_diff,varargin)
% if there are multiple extrema, the match function will take the first one
%% Main: index = find(abs(a-b)==min(abs(a-b)));
switch  nargin
    case 1
        disp('We need two inputs my friends.');
        Index = NaN;
        return
    case 2
        Abs_dif = abs(a-b);
        Index = find(Abs_dif==min(Abs_dif), 1);
        Diff_val = min(Abs_dif);
    case 3
        Abs_dif = abs(a-b);
        Index = find(Abs_dif==min(Abs_dif), 1);
        if Abs_dif(Index)>max_diff
            Index = NaN;
        end
        Diff_val = min(Abs_dif);
end
