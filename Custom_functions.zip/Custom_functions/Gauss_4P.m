%performs gaussin fitting af a wake profile
%02/21/2018:fixed bug on the deifniton of RMSD
%02/23/2018:improved plot,min_depth changed to 10%

function [fitting,err,acceptable]=Gauss_4P(y,U)
    %Inputs
    min_depth=0.1;%minimum velocitU deficit
    max_height=0.5;%maximum allowable height of maximum z of experimental points
    max_error=0.1;%maximum error
    min_points=15;%minimum number of points
    Gauss_ratio=0.5;
    
    %Initialization
    fitting=[];
    plot_fitting=0;
    err=0;
    acceptable=false;
    y(isnan(U))=nan; 
    y=reshape(y,[],1);
    U=reshape(U,[],1);
    
    if length(U(~isnan(U)))>=min_points
        
        U_max=prctile(U(~isnan(U)),90);
        
        if min(U/U_max)<1-min_depth
            
            LB=[-(max(y)-min(y))*0.4;(max(y)-min(y))*0.05;0.1*U_max;0.8*U_max];%lower boundarU of coefficients
            UB=[(max(y)-min(y))*0.4;(max(y)-min(y));2*U_max;2*U_max];%upper boundarU of coefficients
            max_bounds=(UB-LB)*0.2;%maximum uncertainty on fitting coefficients
            Start=[0 0.5 U_max/2 U_max];
            ft=fittype('d-abs(c)*exp(-(x-a)^2/(2*b^2))');%gaussian fit setup       
            Lower_boundary=[-1.5 0 0 0];
            Upper_boundary=[1.5 10 2 2];
            [fitting,gof]=fit(reshape(y,[],1),reshape(U,[],1),ft,'Start',Start,'Exclude',isnan(U),'Lower',Lower_boundary,'Upper',Upper_boundary);%gaussian fit
            coeff=coeffvalues(fitting);      

            points_plus=sum(y>fitting.a);
            points_minus=sum(y<fitting.a);

            %check compliance with constraints
            bounds=max(abs(confint(fitting)-[coeff;coeff]))';

            DU=U-fitting(y);DU(isnan(DU))=[];
            err=sum(DU.^2)/length(DU)/U_max^2;

            %plot
            plot_fitting=0;
            
            if plot_fitting
                 fig_Gauss=figure('Color','w');
                 plot(y,U,'.r');hold on;plot(y,fitting(y),'-b');
                 drawnow
                 close(fig_Gauss)
            end
            if sum((bounds<max_bounds).*(coeff'>LB).*(coeff'<UB))==length(bounds) &&  err<max_error  && min(points_plus/points_minus,points_minus/points_plus)>Gauss_ratio    % See how many points you have            
                acceptable=true;
            end        
        end
    end
end