function [Jen]= Jensen_model_opt(U_field, Xm, Rm, Ct_vec,k_vec)
% Given the Lidar data, optimize the parameter in Jensen model.
%% Input
X_down = 7;
Vec1 = reshape(U_field,[],1);

%% Main

PE_Jen = [];
for id_ct = 1:length(Ct_vec)
    for id_k = 1:length(k_vec)
        % Method 1; Fast approach, Ini Value sensitive 
%         deleted
        % Method 2
        disp(['Jensen ', num2str(((id_ct-1)*length(k_vec)+id_k)/(length(Ct_vec)*length(k_vec))*100),'%'])
     
        R_Jen_opt = 0.5 + k_vec(id_k)*(Xm);
        Jen_Um = (1 - (1-sqrt(1-Ct_vec(id_ct)))./(1+2*k_vec(id_k)*(Xm)).^2);
        Jen_Um((abs(Rm)>R_Jen_opt))=1;

        Vec2 = reshape(Jen_Um,[],1);
        % Wake region
        index_x_r = reshape(logical((abs(Xm)<=X_down).*(abs(Rm)<=R_Jen_opt)),[],1);
        % Percentage Error
        PE_Jen(id_ct,id_k) = nanmean(abs(Vec2(index_x_r) - Vec1(index_x_r))./Vec1(index_x_r)); 
        
    end
end

% The minimum PE
[index_ctmin,index_kmin] = find(PE_Jen==(nanmin(nanmin(PE_Jen))));
Ct_opt = Ct_vec(index_ctmin);
k_opt = k_vec(index_kmin);

Jen_Umopt = 1 - (1-sqrt(1-Ct_opt))./(1+2*k_opt*(Xm)).^2;
R_Jen_opt = 0.5 + k_opt*(Xm);

% Outside the defined wake width
Jen_Umopt((abs(Rm)>R_Jen_opt))=nan;

% Export data
Jen.PE_min =  PE_Jen(index_ctmin,index_kmin);
Jen.Jen_Umopt = Jen_Umopt;
Jen.Ct_opt = Ct_opt;
Jen.k_opt = k_opt;