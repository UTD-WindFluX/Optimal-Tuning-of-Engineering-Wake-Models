function [Lars]= Larsen_model_opt(U_field, Xm, Rm, Ct_vec,c1_vec,x0_vec)
% Given the Lidar data, optimize the parameter in Bastankhah model.
%% Input
X_down = 7;
R = Rm(:,1);
X = Xm(1,:);
Xmin = 1.75; % !!!shift the grid to the initial wake width.
Nc = length(Ct_vec);
N1 = length(c1_vec);
N0 = length(x0_vec);
PE_Lars = nan(Nc, N1,N0);
A = pi/4 * 1^2;

Vec1 = reshape(U_field,[],1);
Xm_half = Xm(R>0,:);
Rm_half = Rm(R>0,:);
%% Main
for id_ct = 1:Nc
    for id_c1 = 1:N1
        for id_x0 = 1:N0
            disp(['Larsen: ', num2str(((id_ct-1)*N1*N0 +(id_c1-1)*N0+id_x0)/(Nc*N1*N0)*100),'%'])
               Ct_test = Ct_vec(id_ct);
               c1_test = c1_vec(id_c1);
               x0_test = x0_vec(id_x0);

                % First order solution
                % Wake width
                Rw_M = (35/2/pi)^(1/5)*(3*c1_test^2)^(1/5)*(Ct_test*A.*(X+x0_test+Xmin)).^(1/3);
                Index_R=reshape(logical((abs(Xm)<=X_down).*(abs(Rm)<=repmat(Rw_M,size(Rm,1),1))),[],1);
                
                % First order solution
                Lasn_fst_half = -1/9 * (Ct_test.*A.*(Xm_half+x0_test+Xmin).^(-2)).^(1/3).*...
                    ((Rm_half).^(3/2).*(3.*c1_test.^2.*Ct_test.*A.*(Xm_half+x0_test+Xmin)).^(-1/2)-...
                    (35/(2*pi))^(3/10)*(3*c1_test^2)^(-1/5)).^2;
                Lasn_fst = [flipud(Lasn_fst_half);Lasn_fst_half];
                Lasn_fst(abs(Rm)>repmat(Rw_M,size(Rm,1),1)) = 0;

                % Second order solution
                Cm_term = 4/81*((35/(2*pi))^(1/5)*(3*c1_test^2)^(-2/15))^(6);
                d0 = Cm_term*(-1-3*(4-12*(6+27*(-4+48/40)*1/19)*1/4)*1/5)*1/8;
                d1 = Cm_term*(4-12*(6+27*(-4+48/40)*1/19)*1/4)*1/5;
                d2 = Cm_term*(6+27*(-4+48/40)*1/19)*1/4;
                d3 = Cm_term*(-4+48/40)*1/19;
                d4 = Cm_term*1/40;
                z_xr = Rm_half.^(3/2).*(Ct_test*A*(Xm_half+x0_test+Xmin)).^(-1/2)*(35/(2*pi))^(-3/10)*(3*c1_test^2)^(-3/10);
                Sum_dz = d0.*z_xr.^(0) + d1.*z_xr.^(1) + d2.*z_xr.^(2) + d3.*z_xr.^(3) + d4.*z_xr.^(4);
                Lasn_sec_half = (Ct_test*A*(Xm_half+x0_test+Xmin).^(-2)).^(2/3).*Sum_dz;
                Lasn_sec = [flipud(Lasn_sec_half);Lasn_sec_half];
                Lasn_sec(abs(Rm)>repmat(Rw_M,size(Rm,1),1)) = 0;

                % first order + second order, to get the
                % deficit. Definition is the negative deficit
                Vec2 = reshape(1+(Lasn_fst+Lasn_sec),[],1);
                % Calculate Norm
                PE_Lars(id_ct,id_c1,id_x0) =  nanmean(abs(Vec2(Index_R) - Vec1(Index_R))./Vec1(Index_R));

        end
    end
end 

PE_Lars(PE_Lars==0)=nan;
min_index = find(PE_Lars==(nanmin(nanmin(nanmin(PE_Lars)))));
[index_ctmin,index_c1min,index_x0min] = ind2sub(size(PE_Lars),min_index);
PE_Lars_min = PE_Lars(index_ctmin,index_c1min,index_x0min);

% Reconstruct the optimal wake feild
Ct_opt = Ct_vec(index_ctmin);
c1_opt = c1_vec(index_c1min);
x0_opt = x0_vec(index_x0min);

Rw_opt = (35/2/pi)^(1/5)*(3*c1_opt^2)^(1/5)*(Ct_opt*A.*(X+x0_opt+Xmin)).^(1/3);

LS_opt_fst_half = -1/9 * (Ct_opt.*A.*(Xm_half+x0_opt+Xmin).^(-2)).^(1/3).*...
    ((Rm_half).^(3/2).*(3.*c1_opt.^2.*Ct_opt.*A.*(Xm_half+x0_opt+Xmin)).^(-1/2)-...
    (35/(2*pi))^(3/10)*(3*c1_opt^2)^(-1/5)).^2;

Cm_term = 4/81*((35/(2*pi))^(1/5)*(3*c1_opt^2)^(-2/15))^(6);
d0 = Cm_term*(-1-3*(4-12*(6+27*(-4+48/40)*1/19)*1/4)*1/5)*1/8;
d1 = Cm_term*(4-12*(6+27*(-4+48/40)*1/19)*1/4)*1/5;
d2 = Cm_term*(6+27*(-4+48/40)*1/19)*1/4;
d3 = Cm_term*(-4+48/40)*1/19;
d4 = Cm_term*1/40;
z_xr = Rm_half.^(3/2).*(Ct_opt*A*(Xm_half+x0_opt+Xmin)).^(-1/2)*(35/(2*pi))^(-3/10)*(3*c1_opt^2)^(-3/10);
Sum_dz = d0.*z_xr.^(0) + d1.*z_xr.^(1) + d2.*z_xr.^(2) + d3.*z_xr.^(3) + d4.*z_xr.^(4);
Lasn_sec_opt_half = (Ct_opt*A*(Xm_half+x0_opt+Xmin).^(-2)).^(2/3).*Sum_dz;

% 1 + delta U becuase the definition of Deficit is negative in
% Larsen model
LS_opt_half = 1+(LS_opt_fst_half+Lasn_sec_opt_half);% change deficit into velocity feild
LS_opt = [flipud(LS_opt_half);LS_opt_half]; 
LS_opt(abs(Rm)>repmat(Rw_opt,size(Rm,1),1)) = nan;

%% Export data

Lars.PE_min =  PE_Lars_min;
Lars.LS_opt_fst_half = LS_opt_fst_half;
Lars.Lasn_sec_opt_half = Lasn_sec_opt_half;
Lars.LS_opt = LS_opt;

Lars.Ct_opt = Ct_opt;
Lars.c1_opt = c1_opt;
Lars.x0_opt = x0_opt;
